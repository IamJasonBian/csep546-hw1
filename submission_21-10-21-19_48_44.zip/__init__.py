from . import poly_regression, ridge_regression_mnist, ridge_regression_cos

__all__ = ["poly_regression", "ridge_regression_mnist", "ridge_regression_cos"]
