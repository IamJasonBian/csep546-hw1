from . import ridge_regression_cos

__all__ = ["ridge_regression_cos"]
